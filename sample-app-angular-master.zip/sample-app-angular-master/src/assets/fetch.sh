#!/bin/sh
curl -o messages.txt http://beta.json-generator.com/api/json/get/VJl5GbIze
curl -o contacts.json http://beta.json-generator.com/api/json/get/V1g6UwwGx
