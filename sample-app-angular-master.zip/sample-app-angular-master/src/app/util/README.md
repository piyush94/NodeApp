## Contents

### Utility Code
- *sessionStorage.js*: Provides an API that emulates a RESTful client API
- *util.js*: various utility functions
- *revertableModel*.js: Provides an API allowing an edited object to be reverted