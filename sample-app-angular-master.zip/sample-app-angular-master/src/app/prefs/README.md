### The NgModule

- *prefs.module*.ts: A feature module (NgModule) which manages user preferences

## NgModule Contents

### The prefs states

- *prefs.states*.ts: Defines the ui-router states for preferences feature

### The prefs components

- *prefs.component*.js: A component for showing and/or updating user preferences.
